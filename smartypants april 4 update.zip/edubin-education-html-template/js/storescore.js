function sendScoreToPHP(score) {
    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();
    
    // Configure it: GET-request for the URL /store_score.php
    xhr.open('POST', 'store_score.php', true);
    
    // Set up the request header
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    
    // Define what happens on successful data submission
    xhr.onload = function () {
        if (xhr.status === 200) {
            // Request was successful, do something if needed
            console.log('Score sent successfully');
        } else {
            // Error handling
            console.log('Error occurred while sending score');
        }
    };
    
    // Send the request
    xhr.send('score=' + encodeURIComponent(score));
}

