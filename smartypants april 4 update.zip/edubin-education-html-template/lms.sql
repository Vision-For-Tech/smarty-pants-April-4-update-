CREATE TABLE users(
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255),
    password VARCHAR(255),
    email VARCHAR(255),
    TIMESTAMP reg_date,
    gender BOOLEAN,
)

CREATE TABLE IF NOT EXISTS subjects(
    subject_id PRIMARY KEY INT (4),
    subject_name VARCHAR (255),
)

CREATE TABLE scores (
    score INT (10),
    FOREIGN KEY users.id,
    Foreign Key (subjects.subject-name)
)