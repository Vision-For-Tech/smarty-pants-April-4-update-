<?php
include('navbar-philosophy.php');
?>
    <div class="header">
        <div class="syllabus">
            <h1>Cambridge IGCSE Philosophy (0940)</h1>
            <p>Explore the fascinating world of reality!</p>
        </div>
        <div class="countdown">
            <span id="timer">60</span> seconds left
            <canvas id="countdownCanvas" width="200" height="200"></canvas>
        </div>
    </div>



  <!--<section style="float: left;" id="syllabus">
    <div class="syllabus_container">
      <div class="syllabus">
        <div class="dropdown">
        <a style="font-size: 2rem;" class="menu" href="#" >||| Menu</a>
        <div class="dropdown-content">
        <ul style="display: block;font-size: 1.2rem;">
          <li>1. Number</li>
          <li>2. Algebra</li>
          <li>3.Trigonometry</li>
          <li>4. Statistics</li>
          <li>5. Probability</li>
        </ul>
        </div>
        </div>
      </div>
    </div>

  </section>-->



 <section style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">
 <form style="margin-left: 200px; margin-top: 50px;" id="quizForm">
  
        <div style="background-color: aqua; border-radius: 30px;" class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">1. According to existentialism, which of the following statements best captures the essence of human existence?</p>
          <label>
            <input type="radio" name="q1" value="Humans are primarily rational beings driven by logic and reason"> Humans are primarily rational beings driven by logic and reason
          </label><br>
          <label>
            <input type="radio" name="q1" value="Humans are defined by their social roles and responsibilities within society.">Humans are defined by their social roles and responsibilities within society.
          </label><br>
          <label>
            <input type="radio" name="q1" value="Humans are free to create their own meaning and purpose in life."> Humans are free to create their own meaning and purpose in life.
          </label><br>
          <label>
            <input type="radio" name="q1" value="Humans are inherently evil and require strict moral guidelines for guidance."> Humans are inherently evil and require strict moral guidelines for guidance.
          </label><br>
        </div>
        
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <br><div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">2. Which philosopher is associated with the concept of the “veil of ignorance,” which proposes that justice is achieved when decision-makers are unaware of their own personal characteristics and circumstances??</p>
          <label>
            <input type="radio" name="q2" value="John Stuart Mill"> John Stuart Mill
          </label><br>
          <label>
            <input type="radio" name="q2" value="Immanuel Kant"> Immanuel Kant
          </label><br>
          <label>
            <input type="radio" name="q2" value="John Rawls"> John Rawls
          </label><br>
          <label>
            <input type="radio" name="q2" value="Thomas Hobbes">Thomas Hobbes
          </label><br>
        </div></br>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. What is the central theme of Friedrich Nietzsche’s philosophy of nihilism?</p>
          <label>
            <input type="radio" name="q3" value="The belief in the existence of objective moral values and duties"> The belief in the existence of objective moral values and duties
          </label><br>
          <label>
            <input type="radio" name="q3" value="The rejection of all religious and moral principles as baseless and meaningless">The rejection of all religious and moral principles as baseless and meaningless
          </label><br>
          <label>
            <input type="radio" name="q3" value="The promotion of utilitarian ethics based on the greatest happiness for the greatest number"> The promotion of utilitarian ethics based on the greatest happiness for the greatest number
          </label><br>
          <label>
            <input type="radio" name="q3" value="The advocacy for individual autonomy and self-determination"> The advocacy for individual autonomy and self-determination
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">4. Which of the following statements best represents the philosophy of stoicism?</p>
          <label>
            <input type="radio" name="q4" value="Happiness is achieved through the pursuit of pleasure and the avoidance of pain."> Happiness is achieved through the pursuit of pleasure and the avoidance of pain.
          </label><br>
          <label>
            <input type="radio" name="q4" value="Happiness is found by living in accordance with nature and accepting things beyond one’s control."> Happiness is found by living in accordance with nature and accepting things beyond one’s control.
          </label><br>
          <label>
            <input type="radio" name="q4" value="Happiness is attained through the pursuit of intellectual knowledge and wisdom.">Happiness is attained through the pursuit of intellectual knowledge and wisdom.
          </label><br>
          <label>
            <input type="radio" name="q4" value="Happiness is obtained by fulfilling one’s desires and materialistic aspirations.">Happiness is obtained by fulfilling one’s desires and materialistic aspirations.
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">5. What is the main argument presented in René Descartes’ famous phrase, “Cogito, ergo sum” (I think, therefore I am)?</p>
          <label>
            <input type="radio" name="q5" value=" The existence of God can be proven through rational deduction.">The existence of God can be proven through rational deduction.
          </label><br>
          <label>
            <input type="radio" name="q5" value="The mind and body are separate entities, with the mind being the source of consciousness and identity."> The mind and body are separate entities, with the mind being the source of consciousness and identity.
          </label><br>
          <label>
            <input type="radio" name="q5" value="Knowledge is acquired through sensory experience and observation of the external world."> Knowledge is acquired through sensory experience and observation of the external world.
          </label><br>
          <label>
            <input type="radio" name="q5" value="The self is an illusion created by societal norms and expectations.">The self is an illusion created by societal norms and expectations.
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">6. Which ethical theory emphasizes the importance of the consequences of actions in determining their moral worth?</p>
          <label>
            <input type="radio" name="q6" value="To identify strengths, weaknesses, opportunities, and threats"> Virtue ethics
          </label><br>
          <label>
            <input type="radio" name="q6" value="Deontological ethics"> Deontological ethics
          </label><br>
          <label>
            <input type="radio" name="q6" value="Utilitarianism"> Utilitarianism
          </label><br>
          <label>
            <input type="radio" name="q6" value="Natural law ethics"> Natural law ethics
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">7.  What is the central tenet of relativism in moral philosophy?</p>
          <label>
            <input type="radio" name="q7" value="Moral values and principles are objective and universal across all cultures and societies">Moral values and principles are objective and universal across all cultures and societies
          </label><br>
          <label>
            <input type="radio" name="q7" value="Moral values and principles are subjective and dependent on individual beliefs and cultural norms.">Moral values and principles are subjective and dependent on individual beliefs and cultural norms.
          </label><br>
          <label>
            <input type="radio" name="q7" value="Moral values and principles are determined by a divine authority or higher power."> Moral values and principles are determined by a divine authority or higher power.
          </label><br>
          <label>
            <input type="radio" name="q7" value="Moral values and principles are inherent in human nature and can be discovered through reason.">Moral values and principles are inherent in human nature and can be discovered through reason.
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">8. Who is known for the philosophical concept of the “eternal recurrence,” which proposes that all events in the universe will repeat themselves infinitely?</p>
          <label>
            <input type="radio" name="q8" value="Socrates">Socrates
          </label><br>
          <label>
            <input type="radio" name="q8" value="Plato">Plato
          </label><br>
          <label>
            <input type="radio" name="q8" value="Friedrich Nietzsche"> Friedrich Nietzsche
          </label><br>
          <label>
            <input type="radio" name="q8" value="Albert Camus"> Albert Camus
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">9. What is the main focus of epistemology as a branch of philosophy?</p>
          <label>
            <input type="radio" name="q9" value="The study of the nature of reality and existence">The study of the nature of reality and existence
          </label><br>
          <label>
            <input type="radio" name="q9" value="The study of the principles of right and wrong conduct"> The study of the principles of right and wrong conduct
          </label><br>
          <label>
            <input type="radio" name="q9" value="The study of knowledge and how it is acquired">The study of knowledge and how it is acquired
          </label><br>
          <label>
            <input type="radio" name="q9" value="The study of the nature of beauty and aesthetics">The study of the nature of beauty and aesthetics
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">10. Which philosophical problem concerns the conflict between free will and determinism, questioning whether human actions are pre-determined by external factors or result from individual choice?</p>
          <label>
            <input type="radio" name="q10" value="The problem of evil"> The problem of evil
          </label><br>
          <label>
            <input type="radio" name="q10" value="The mind-body problem">The mind-body problem
          </label><br>
          <label>
            <input type="radio" name="q10" value="The problem of induction">The problem of induction
          </label><br>
          <label>
            <input type="radio" name="q10" value="The free will problem">The free will problem
          </label><br>
        </div>

        <!--<p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>-->
        
        <button type="button" id="submitButton" onclick="submitQuiz()">Submit</button>
      </form>

    
      </div>
      
      <section style="display: flex;" id="Results">
      <div id="results"></div>
      <div id="correctAnswers"></div>
      </section>
    </section>
      





    <!--

    <section style="margin-left: 500px; font-size: 1.9rem; font-family: cursive;" id="biology">

    <div id="question_1_container">
        <div id="question1">
            <p style="font-size: 2rem;">1. What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>2. What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>What is Biology?</p>
            <ul>
                <li><input type="radio" id="answer" value="true">A</li>
                <li><input type="radio" id="answer" value="true">B</li>
                <li><input type="radio" id="answer" value="true">C</li>
                <li><input type="radio" id="answer" value="true">D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>

    -->
 </section>


    

  <footer id="footer-part">
        <div class="footer-top pt-40 pb-70">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="footer-about mt-40">
                            <div class="logo">
                                <a href="#"><img style="width: 100px; height: 100px;" src="images/smartypants.png" alt="Logo"></a>
                            </div>
                            <p>Gravida nibh vel velit auctor aliquetn quibibendum auci elit cons equat ipsutis sem nibh id elit. Duis sed odio sit amet nibh vulputate.</p>
                            <ul class="mt-20">
                                <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            </ul>
                        </div> <!-- footer about -->
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="footer-link mt-40">
                            <div class="footer-title pb-25">
                                <h6>Sitemap</h6>
                            </div>
                            <ul>
                                <li><a href="index-2.html"><i class="fa fa-angle-right"></i>Home</a></li>
                                <li><a href="about.html"><i class="fa fa-angle-right"></i>About us</a></li>
                                <li><a href="courses.html"><i class="fa fa-angle-right"></i>Courses</a></li>
                            </ul>
                            <ul>
                                <li><a href="contact.html"><i class="fa fa-angle-right"></i>Contact</a></li>
                            </ul>
                        </div> <!-- footer link -->
                    </div>
                    <div class="col-lg-2 col-md-6 col-sm-6">
                        <div class="footer-link support mt-40">
                            <div class="footer-title pb-25">
                                <h6>Support</h6>
                            </div>
                            <ul>
                                <li><a href="#"><i class="fa fa-angle-right"></i>FAQS</a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Privacy</a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Policy</a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Support</a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Documentation</a></li>
                            </ul>
                        </div> <!-- support -->
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-address mt-40">
                            <div class="footer-title pb-25">
                                <h6>Contact Us</h6>
                            </div>
                            <ul>
                                <li>
                                    <div class="icon">
                                        <i><img src="images/phone.png"></i>
                                    </div>
                                    <div class="cont">
                                        <p>+260 774029981</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-envelope-o"></i>
                                    </div>
                                    <div class="cont">
                                        <p>visionfortech@gmail.com</p>
                                    </div>
                                </li>
                            </ul>
                        </div> <!-- footer address -->
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- footer top -->
        
        <div class="footer-copyright pt-10 pb-25">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                    </div>
                    <div class="col-md-4">
                        <div class="copyright text-md-right text-center pt-15">
                           
                        </div>
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- footer copyright -->
    </footer>
    
    <!--====== FOOTER PART ENDS ======-->
   
    <!--====== BACK TO TP PART START ======-->
    
    <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>




    <script>
            // Countdown timer
            let timeLeft = 100;
      const timerElement = document.getElementById('timer');
      const submitButton = document.getElementById('submitButton');

      window.onload = function() {
        alert("You have 100s to solve this quiz or else")
      }


      function updateTimer() {
          timerElement.textContent = timeLeft;
          if (timeLeft === 0) {
              submitQuiz();
                submitButton.disabled = true;
                alert("TIME UP!!!!");
          } else {
              timeLeft--;
              setTimeout(updateTimer, 1000);
          }
      }

      updateTimer();

        // Add loaded class to body after 10 seconds
      setTimeout(function() {
      document.body.classList.add('loaded');
      }, 5000,500); // 10 seconds delay

      function submitQuiz() {
  var subject = 'Biology';
  var answers = {};
  var questions = document.querySelectorAll('.question');
  
  questions.forEach(function(question, index) {
    var input = question.querySelector('input:checked');
    if (input) {
      answers[(index + 1)] = input.value;
    } else {
      answers['q' + (index + 1)] = 'No Answer';
    }
    sendScoreToPHP(score,subject);
  });
  
  // Display results
  var resultsDiv = document.getElementById('results');
  //resultsDiv.innerHTML = '<h2>Results:</h2>';
  //Object.keys(answers).forEach(function(question, index) {
  //  resultsDiv.innerHTML += '<p>' + question + ': ' + answers[question] + '</p>';
  //});

 var correctAnswers = ['Chlorophyll a', 'Cellular Respiration', 'Ribosome','Osmosis','Regulation of body temperature','Interphase, metaphase, prophase, anaphase, telophase','Regulation of heartbeat','Breaks down carbohydrates into simple sugars','Wind','Exchange of gases'];

 var userAnswers = answers;



 //var correctDiv = document.getElementById('correctAnswers');
  //correctDiv.innerHTML = '<h2>Correct Answers:</h2>';
  //Object.keys(correctAnswers).forEach(function(question, index) {
    //correctDiv.innerHTML += '<p style="color: green;">' + question + ': ' + correctAnswers[question - 1] + '</p>';
  //});


 
var score = 0;
for (var i = 0; i < correctAnswers.length; i++) {
    if (correctAnswers[i] === userAnswers[(i + 1)]) {
        score++;
    }
 }

 // Display results
 resultsDiv.innerHTML += '<h2>Biology</h2><br></br><p>Total Score: ' + score + ' out of ' + correctAnswers.length + '</p>';
 
 var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("submitButton");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal
btn.onclick = function() {
modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
modal.style.display = "none";
}


}

function sendScoreToPHP(score,subject) {
    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();
    
    // Configure it: POST request for the URL store_score.php
    xhr.open('POST', 'store_score.php', true);
    
    // Set up the request header
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    
    // Define what happens on successful data submission
    xhr.onload = function () {
        if (xhr.status === 200) {
            // Request was successful, do something if needed
            console.log('Form sent successfully');
        } else {
            // Error handling
            console.log('Error occurred while sending score');
        }
    };
    
    // Send the request with score, username, and subject
    xhr.send('score=' + encodeURIComponent(score) +  '&subject=' + encodeURIComponent(subject));
}




    </script> 
</body>
</html>
