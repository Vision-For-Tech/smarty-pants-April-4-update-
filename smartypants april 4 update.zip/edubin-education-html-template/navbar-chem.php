<!doctype html>
<html lang="en">
<head>
   
    <!--====== Required meta tags ======-->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!--====== Title ======-->
    <title>Chemistry</title>
    
    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="images/smartypants.png" type="image/png">

    <!--====== Slick css ======-->
    <link rel="stylesheet" href="css/slick.css">

    <!--====== Animate css ======-->
    <link rel="stylesheet" href="css/animate.css">
    
    <!--====== Nice Select css ======-->
    <link rel="stylesheet" href="css/nice-select.css">
    
    <!--====== Nice Number css ======-->
    <link rel="stylesheet" href="css/jquery.nice-number.min.css">

    <!--====== Magnific Popup css ======-->
    <link rel="stylesheet" href="css/magnific-popup.css">

    <!--====== Bootstrap css ======-->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!--====== Fontawesome css ======-->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    
    <!--====== Default css ======-->
    <link rel="stylesheet" href="css/default.css">
    
    <!--====== Style css ======-->
    <link rel="stylesheet" href="css/style.css">
    
    <!--====== Responsive css ======-->
    <link rel="stylesheet" href="css/responsive.css">

    <link rel="stylesheet" href="css/bootsrap.css">

    <!--<link rel="stylesheet" href="css/DT_bootstrap.css">-->

    <!--<link rel="stylesheet" href="css/bootstrap-responsive.css">-->
  
  
</head>

<style>
/* Reset default styles */
* {
    padding: 0;
    margin: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background-color: #f5f5f5;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px;
    background-color: #0074d9;
    color: #fff;
}

.syllabus h1 {
    font-size: 24px;
    font-weight: bold;
}

.countdown {
    font-size: 18px;
}


#countdown {
        width: 100px;
        height: 100px;
        position: relative;
    }

    #countdown .progress {
        width: 100%;
        height: 100%;
        border-radius: 50%;
        background-color: #ccc;
    }

    #countdown .progress-bar {
        width: 100%;
        height: 100%;
        border-radius: 50%;
        background-color: #f00;
        clip-path: polygon(50% 0%, 100% 0%, 100% 100%, 50% 100%);
        position: absolute;
        top: 0;
    }

.dropdown-content {
  display: none;
  overflow-y: visible;
  position: absolute;
  width: fit-content;
  margin-top: 45px;
  background-color: #f1f1f1;
  min-width: 100px;
  text-align: left;
  height: fit-content;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: #ddd;}

/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {display: list-item;}

/* Change the background color of the dropdown button when the dropdown content is shown */
.dropdown:hover .dropbtn {background-color: #3e8e41;}

/* Other styles for quiz questions, buttons, etc. */
/* Customize as needed */
/* ... */

</style>

<body>
   
    <!--====== PRELOADER PART START ======-->
    
    <div id="preloader">
        <div class="dot"></div>
        <div class="dot1"></div>
        <div class="dot2"></div>
        <p class="preloader-text">Loading...</p>
    </div>

    
    <!--====== PRELOADER PART START ======-->
    
    <!--====== HEADER PART START ======-->
    <?php 
                                  session_start(); 
                            ?>
    
    <header id="header-part">
       
        <div class="header-top d-none d-lg-block">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="header-contact text-lg-left text-center">
                            <ul>
                                <!--<li><img src="images/all-icon/map.png" alt="icon"><span>127/5 Mark street, New york</span></li>-->
                                <li><img src="images/all-icon/email.png" alt="icon"><span>visionfortech@gmail.com</span></li>
                            </ul>
                        </div>
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- header top -->
        
        <div class="header-logo-support pt-30 pb-30">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-4">
                        <div class="logo">
                            <a href="index-2.html">
                                <img style="width: 100px; height: 100px;" src="images/smartypants.png" alt="Logo">
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-8">
                        <div class="support-button float-right d-none d-md-block">
                            <div class="support float-left">
                                <div class="icon">
                                    <img src="images/phone.png" alt="icon">
                                </div>
                                <div class="cont">
                                    <p>Need Help? call us free</p>
                                    <span>+260 774029981</span>
                                </div>
                            </div>
                            <div style="display: flexbox;" class="button float-left">
                            <button>
                            <img src="images/user-alt.png" alt="img">
                            <?php  
                                  if(isset($_SESSION["username"])) {
                                      echo '<a style="font-size: 20px; font-decoration: uppercase;" href="Editprofile.html">'. $_SESSION["username"] .'</a>';
                                  } else {
                                      echo '<a href="login.html">Login</a>';
                                  }
                            ?>
                            </button>
                            <ul style="margin-top: 40px;">
                                <?php
                                if(isset($_SESSION["username"])) {
                                      echo '<button id="Logout">Logout</button>';
                                  } else {
                                      echo '';
                                  }
                                ?>
                            </ul>
                            </div>
                        </div>
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- header logo support -->
        
        <div class="navigation">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10 col-md-10 col-sm-9 col-8">
                        <nav class="navbar navbar-expand-lg">
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>

                            <div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
                                <ul class="navbar-nav mr-auto">
                                    <li class="nav-item">
                                        <a class="active" href="index-2.html">Home</a>
                                        <ul class="sub-menu">
                                            <li><a class="active" href="index-2.html">Home 01</a></li>
                                            <li><a href="index-3.html">Home 02</a></li>
                                            <li><a href="index-4.html">Home 03</a></li>
                                        </ul>
                                    </li>
                                    <li class="nav-item">
                                        <a href="about.html">About us</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="courses.html">My Courses</a>
                                        <ul class="sub-menu">
                                            <li><a href="courses.html">Courses</a></li>
                                            <li><a href="courses-singel.html">Course Singel</a></li>
                                        </ul>
                                    </li>
                                    <!--<li class="nav-item">
                                        <a href="events.html">Events</a>
                                        <ul class="sub-menu">
                                            <li><a href="events.html">Events</a></li>
                                            <li><a href="events-singel.html">Event Singel</a></li>
                                        </ul>
                                    </li>
                                    <li class="nav-item">
                                        <a href="teachers.html">Our teachers</a>
                                        <ul class="sub-menu">
                                            <li><a href="teachers.html">teachers</a></li>
                                            <li><a href="teachers-singel.html">teacher Singel</a></li>
                                        </ul>
                                    </li>
                                    <li class="nav-item">
                                        <a href="blog.html">Blog</a>
                                        <ul class="sub-menu">
                                            <li><a href="blog.html">Blog</a></li>
                                            <li><a href="blog-singel.html">Blog Singel</a></li>
                                        </ul>
                                    </li>
                                    <li class="nav-item">
                                        <a href="shop.html">Shop</a>
                                        <ul class="sub-menu">
                                            <li><a href="shop.html">Shop</a></li>
                                            <li><a href="shop-singel.html">Shop Singel</a></li>
                                        </ul>
                                    </li>-->
                                    <li class="nav-item">
                                        <a href="contact.html">Contact</a>
                                        <ul class="sub-menu">
                                            <li><a href="contact.html">Contact Us</a></li>
                                            <li><a href="contact-2.html">Contact Info</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </nav> <!-- nav -->
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-3 col-4">
                        <div class="right-icon text-right">
                            <ul style="display: flex; cursor: pointer;">
                                <li><input type="text" placeholder="Search...." id="name" /></li>
                                <li><a href="#" id="search"><i class="fa fa-search"></i></a></li>

                                <!--<li><a href="#"><i class="fa fa-shopping-bag"></i><span>0</span></a></li>-->
                            </ul>
                        </div> <!-- right icon -->
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div>
        
    </header>
