<?php
include('navhead_bio.php');
?>
    <div class="header">
        <div class="syllabus">
            <h1>Cambridge IGCSE Biology (0620)</h1>
            <p>Explore the fascinating world of biology!</p>
        </div>
        <div class="countdown">
            <span id="timer">60</span> seconds left
        </div>
    </div>



 <section style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">
 <form style="margin-left: 200px; margin-top: 50px;" id="quizForm">
  
        <div style="background-color: aqua; border-radius: 30px;" class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">1. Which of the following is the primary pigment responsible for photosynthesis?</p>
          <label>
            <input type="radio" name="q1" value="Chlorophyll a"> Chlorophyll 
          </label><br>
          <label>
            <input type="radio" name="q1" value=" Chlorophyll b">  Chlorophyll b
          </label><br>
          <label>
            <input type="radio" name="q1" value="Carotene"> Carotene
          </label><br>
          <label>
            <input type="radio" name="q1" value="Xanthophyll"> Xanthophyll
          </label><br>
        </div>
        
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <br><div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">2. What is the function of the mitochondria in a cell?</p>
          <label>
            <input type="radio" name="q2" value="Photosynthesis"> Photosynthesis
          </label><br>
          <label>
            <input type="radio" name="q2" value="Cellular respiration"> Cellular respiration
          </label><br>
          <label>
            <input type="radio" name="q2" value="DNA replication"> DNA replication
          </label><br>
          <label>
            <input type="radio" name="q2" value="Protein synthesis">  Protein synthesis
          </label><br>
        </div></br>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">4. What is the process by which water moves across a semipermeable membrane from an area of high concentration to an area of low concentration?</p>
          <label>
            <input type="radio" name="q4" value="Osmosis"> Osmosis
          </label><br>
          <label>
            <input type="radio" name="q4" value="Diffusion"> Diffusion
          </label><br>
          <label>
            <input type="radio" name="q4" value="Active transport"> Active transport
          </label><br>
          <label>
            <input type="radio" name="q4" value="Facilitated diffusion"> Facilitated diffusion
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">5. Which of the following is NOT a function of the circulatory system?</p>
          <label>
            <input type="radio" name="q5" value=" Transport of nutrients">  Transport of nutrients
          </label><br>
          <label>
            <input type="radio" name="q5" value="Regulation of body temperature"> Regulation of body temperature
          </label><br>
          <label>
            <input type="radio" name="q5" value="Removal of waste products"> Removal of waste products
          </label><br>
          <label>
            <input type="radio" name="q5" value="Production of hormones"> Production of hormones
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">6. What is the correct sequence of stages in the cell cycle?</p>
          <label>
            <input type="radio" name="q6" value="Interphase, prophase, metaphase, anaphase, telophase"> Interphase, prophase, metaphase, anaphase, telophase
          </label><br>
          <label>
            <input type="radio" name="q6" value="Prophase, metaphase, anaphase, telophase, interphase"> Prophase, metaphase, anaphase, telophase, interphase
          </label><br>
          <label>
            <input type="radio" name="q6" value="Interphase, metaphase, prophase, anaphase, telophase"> Interphase, metaphase, prophase, anaphase, telophase
          </label><br>
          <label>
            <input type="radio" name="q6" value="Metaphase, anaphase, prophase, telophase, interphase"> Metaphase, anaphase, prophase, telophase, interphase
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">7.  Which of the following is NOT a function of the nervous system?</p>
          <label>
            <input type="radio" name="q7" value="Coordination of body movements"> Coordination of body movements
          </label><br>
          <label>
            <input type="radio" name="q7" value="Regulation of heartbeat"> Regulation of heartbeat
          </label><br>
          <label>
            <input type="radio" name="q7" value="Production of hormones"> Production of hormones
          </label><br>
          <label>
            <input type="radio" name="q7" value="Processing sensory information">Processing sensory information
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">8. What is the function of the enzyme amylase?</p>
          <label>
            <input type="radio" name="q8" value="Breaks down proteins into amino acids"> Breaks down proteins into amino acids
          </label><br>
          <label>
            <input type="radio" name="q8" value=" Breaks down carbohydrates into simple sugars"> Breaks down carbohydrates into simple sugars
          </label><br>
          <label>
            <input type="radio" name="q8" value="Breaks down fats into fatty acids and glycerol"> Breaks down fats into fatty acids and glycerol
          </label><br>
          <label>
            <input type="radio" name="q8" value="Breaks down nucleic acids into nucleotides"> Breaks down nucleic acids into nucleotides
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">9. Which of the following is a renewable energy resource?</p>
          <label>
            <input type="radio" name="q9" value="Coal"> Coal
          </label><br>
          <label>
            <input type="radio" name="q9" value="Natural gas"> Natural gas
          </label><br>
          <label>
            <input type="radio" name="q9" value="Wind"> Wind
          </label><br>
          <label>
            <input type="radio" name="q9" value="Nuclear energy"> Nuclear energy
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">10. What is the role of stomata in plant leaves?</p>
          <label>
            <input type="radio" name="q10" value="Absorption of sunlight"> Absorption of sunlight
          </label><br>
          <label>
            <input type="radio" name="q10" value="Exchange of gases"> Exchange of gases
          </label><br>
          <label>
            <input type="radio" name="q10" value="Storage of water"> Storage of water
          </label><br>
          <label>
            <input type="radio" name="q10" value="Transport of nutrients"> Transport of nutrients
          </label><br>
        </div>

        <!--<p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>-->
        
        <button type="button" id="submitButton" onclick="submitQuiz()">Submit</button>
        <button type="button" id="viewresults">View Results</button>
      </form>

    
      </div>

      <div id="myModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <section style="display: flex;" id="Results">
            <p id="results"></p>
           <p id="correctAnswers"></p>
            </section>
           <!--<p style="font-size: 2rem;">Your score is.</p>-->
        </div>  
      </div>
      
      <!--<section style="display: flex;" id="Results">
      </section>-->
    </section>
      







    <!--<section style="margin-left: 500px; font-size: 1.9rem; font-family: cursive;" id="biology">

    <div id="question_1_container">
        <div id="question1">
            <p style="font-size: 2rem;">1. What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>2. What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>What is Biology?</p>
            <ul>
                <li><input type="radio" id="answer" value="true">A</li>
                <li><input type="radio" id="answer" value="true">B</li>
                <li><input type="radio" id="answer" value="true">C</li>
                <li><input type="radio" id="answer" value="true">D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>

 </section>-->


    

  <footer id="footer-part">
        <div class="footer-top pt-40 pb-70">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="footer-about mt-40">
                            <div class="logo">
                                <a href="#"><img style="width: 100px; height: 100px;" src="images/smartypants.png" alt="Logo"></a>
                            </div>
                            <p>Gravida nibh vel velit auctor aliquetn quibibendum auci elit cons equat ipsutis sem nibh id elit. Duis sed odio sit amet nibh vulputate.</p>
                            <ul class="mt-20">
                                <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            </ul>
                        </div> <!-- footer about -->
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="footer-link mt-40">
                            <div class="footer-title pb-25">
                                <h6>Sitemap</h6>
                            </div>
                            <ul>
                                <li><a href="index-2.html"><i class="fa fa-angle-right"></i>Home</a></li>
                                <li><a href="about.html"><i class="fa fa-angle-right"></i>About us</a></li>
                                <li><a href="courses.html"><i class="fa fa-angle-right"></i>Courses</a></li>
                            </ul>
                            <ul>
                                <li><a href="contact.html"><i class="fa fa-angle-right"></i>Contact</a></li>
                            </ul>
                        </div> <!-- footer link -->
                    </div>
                    <div class="col-lg-2 col-md-6 col-sm-6">
                        <div class="footer-link support mt-40">
                            <div class="footer-title pb-25">
                                <h6>Support</h6>
                            </div>
                            <ul>
                                <li><a href="#"><i class="fa fa-angle-right"></i>FAQS</a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Privacy</a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Policy</a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Support</a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Documentation</a></li>
                            </ul>
                        </div> <!-- support -->
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-address mt-40">
                            <div class="footer-title pb-25">
                                <h6>Contact Us</h6>
                            </div>
                            <ul>
                                <li>
                                    <div class="icon">
                                        <i><img src="images/phone.png"></i>
                                    </div>
                                    <div class="cont">
                                        <p>+260 774029981</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-envelope-o"></i>
                                    </div>
                                    <div class="cont">
                                        <p>visionfortech@gmail.com</p>
                                    </div>
                                </li>
                            </ul>
                        </div> <!-- footer address -->
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- footer top -->
        
        <div class="footer-copyright pt-10 pb-25">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                    </div>
                    <div class="col-md-4">
                        <div class="copyright text-md-right text-center pt-15">
                           
                        </div>
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- footer copyright -->
    </footer>
    
    <!--====== FOOTER PART ENDS ======-->
   
    <!--====== BACK TO TP PART START ======-->
    
    <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>




    <script>
            // Countdown timer
      let timeLeft = 100;
      const timerElement = document.getElementById('timer');
      const submitButton = document.getElementById('submitButton');

      window.onload = function() {
        alert("You have 100s to solve this quiz or else")
      }


      function updateTimer() {
          timerElement.textContent = timeLeft;
          if (timeLeft === 0) {
              submitQuiz();
                submitButton.disabled = true;
                alert("TIME UP!!!!");
          } else {
              timeLeft--;
              setTimeout(updateTimer, 1000);
          }
      }

      updateTimer();

        // Add loaded class to body after 10 seconds
      setTimeout(function() {
      document.body.classList.add('loaded');
      }, 5000,500); // 10 seconds delay

      function submitQuiz() {
  var subject = 'Biology';
  var answers = {};
  var questions = document.querySelectorAll('.question');
  
  questions.forEach(function(question, index) {
    var input = question.querySelector('input:checked');
    if (input) {
      answers[(index + 1)] = input.value;
    } else {
      answers['q' + (index + 1)] = 'No Answer';
    }
    
  });
  
  // Display results
  var resultsDiv = document.getElementById('results');
  //resultsDiv.innerHTML = '<h2>Results:</h2>';
  //Object.keys(answers).forEach(function(question, index) {
  //  resultsDiv.innerHTML += '<p>' + question + ': ' + answers[question] + '</p>';
  //});

 var correctAnswers = ['Chlorophyll a', 'Cellular Respiration', 'Ribosome','Osmosis','Regulation of body temperature','Interphase, metaphase, prophase, anaphase, telophase','Regulation of heartbeat','Breaks down carbohydrates into simple sugars','Wind','Exchange of gases'];

 var userAnswers = answers;



 //var correctDiv = document.getElementById('correctAnswers');
  //correctDiv.innerHTML = '<h2>Correct Answers:</h2>';
  //Object.keys(correctAnswers).forEach(function(question, index) {
    //correctDiv.innerHTML += '<p style="color: green;">' + question + ': ' + correctAnswers[question - 1] + '</p>';
  //});


 
var score = 0;
for (var i = 0; i < correctAnswers.length; i++) {
    if (correctAnswers[i] === userAnswers[(i + 1)]) {
        score++;
    }
 }

 // Display results
 resultsDiv.innerHTML += '<h2>Biology</h2><br></br><p>Total Score: ' + score + ' out of ' + correctAnswers.length + '</p>';
 sendScoreToPHP(score,subject);
 


 var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("viewresults");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal
btn.onclick = function() {
modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
modal.style.display = "none";
}

submitButton.disabled = true;
}

function sendScoreToPHP(score,subject) {
    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();
    
    // Configure it: POST request for the URL store_score.php
    xhr.open('POST', 'store_score.php', true);
    
    // Set up the request header
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    
    // Define what happens on successful data submission
    xhr.onload = function () {
        if (xhr.status === 200) {
            // Request was successful, do something if needed
            console.log('Form sent successfully');
        } else {
            // Error handling
            console.log('Error occurred while sending score');
        }
    };
    
    // Send the request with score, username, and subject
    xhr.send('score=' + encodeURIComponent(score) +  '&subject=' + encodeURIComponent(subject));
}




    </script> 
</body>
</html>
