<?php

session_start();

// Example database connection and insertion
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smartypants";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);


$score = isset($_POST['score']) ? $_POST['score'] : '';
$user = isset($_SESSION["username"]) ? $_SESSION["username"] : ''; // Retrieve username from session variable
$subject = isset($_POST['subject']) ? $_POST['subject'] : ''; 


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    echo "Connected to ". $dbname;
    echo $user;
    echo $subject;
    echo $score;
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Prepare SQL statement to insert score into database
    $stmt = $conn->prepare("INSERT INTO scores (user,score,subject) VALUES (?, ?, ?)");
    $stmt->bind_param("sis", $user, $score,$subject,); // Assuming score is an integer, adjust if necessary

    // Execute the statement
    if ($stmt->execute()) {
        echo "Score stored successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    echo $user;
    echo $subject;

    // Close statement
    $stmt->close();
}

echo 'Hello';


// Close connection
$conn->close();
?>
<script>
           setTimeout(function() {
      document.body.classList.add('loaded');
      }, 8000,500); // 10 seconds delay
    </script>
