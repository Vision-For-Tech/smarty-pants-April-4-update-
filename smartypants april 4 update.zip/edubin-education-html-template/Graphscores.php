<?php
include('navhead.php');
?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<body>
    <div  style="margin-top: 50px;">
    <h1 style="font-size: 1.2rem;">Subject Scores Bar Chart</h1>

    <div>
        <label for="subjectSelect">Select Subject:</label>
        <select id="subjectSelect">
            <option value="Math">Math</option>
            <option value="Science">Science</option>
            <!-- Add more options as needed -->
        </select>
        <button onclick="fetchAndDraw()">Fetch Scores</button>
    </div>

    <div style="width: 80%; margin: 20px auto;">
        <canvas id="scoreChart"></canvas>
    </div>
</div>

    <script>
                // Add loaded class to body after 10 seconds
      setTimeout(function() {
      document.body.classList.add('loaded');
      }, 5000,500); // 10 seconds delay


        function fetchAndDraw() {
            var subject = document.getElementById('subjectSelect').value;

            // Make an AJAX request to fetch scores for the selected subject
            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'fetch_scores.php?subject=' + encodeURIComponent(subject), true);
            xhr.onload = function () {
                if (xhr.status === 200) {
                    var scoresData = JSON.parse(xhr.responseText);
                    drawChart(scoresData);
                } else {
                    console.error('Error fetching scores:', xhr.status);
                }
            };
            xhr.send();
        }

        function drawChart(scoresData) {
            var labels = [];
            var scores = [];

            // Extract labels and scores from scoresData
            scoresData.forEach(function (entry) {
                labels.push(entry.user);
                scores.push(entry.score);
            });

            var ctx = document.getElementById('scoreChart').getContext('2d');
            var myChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Scores',
                        data: scores,
                        backgroundColor: 'rgba(54, 162, 235, 0.2)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero: true
                            }
                        }]
                    }
                }
            });
        }
    </script>
</body>
</html>
