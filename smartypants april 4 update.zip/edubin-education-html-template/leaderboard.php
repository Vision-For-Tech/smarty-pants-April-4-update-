<?php
include('navhead.php');
?>
<style>
    body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
    margin: 0;
    padding: 0;
}

.leaderboard {
    width: 80%;
    max-width: 800px;
    margin: 20px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1 {
    text-align: center;
    color: #333;
}

#leaderboardList {
    list-style-type: none;
    padding: 0;
}

#leaderboardList li {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #ccc;
    padding: 10px 0;
}

#leaderboardList li:nth-child(even) {
    background-color: #f9f9f9;
}

#leaderboardList li:last-child {
    border-bottom: none;
}

.leaderboardPosition {
    flex: 0 0 50px;
    text-align: center;
}

.leaderboardName {
    flex: 1;
}

.leaderboardScore {
    flex: 0 0 100px;
    text-align: right;
}

#subjectSelect {
    margin-top: 30px;
}

</style>
<body>
    <div>
        <label for="leaderboardselect">Select Leaderboard:</label>
        <select id="subjectSelect">
            <option></option>
            <option value="Math">Math</option>
            <option value="Biology">Biology</option>
            <option value="I.C.T">I.C.T</option>
            <option value="Physics">Physics</option>
            <option value="Chemistry">Chemistry</option>
            <option value="Business Studies">Business Studies</option>
            <option value="Agriculture">Agriculture</option>
            <option value="Science">Science</option>
            <option value="Math">Math</option>
            <option value="Science">Science</option>
            <!-- Add more options as needed -->
        </select>
        <button onclick="fetchLeaderboardData()">Fetch Scores</button>
    </div>
    <div class="leaderboard">
        <h1>Leaderboard</h1>
        <ol id="leaderboardList">
            <!-- Leaderboard entries will be dynamically added here -->
        </ol>
    </div>

    <script>

          // Add loaded class to body after 10 seconds
      setTimeout(function() {
      document.body.classList.add('loaded');
      }, 5000,500); // 10 seconds delay

        // Function to fetch leaderboard data from the server
// Function to fetch leaderboard data from the server
function fetchLeaderboardData() {
    // Get the selected subject from the dropdown
    var subjectSelect = document.getElementById('subjectSelect');
    var subject = subjectSelect.value;
    console.log(subject);

    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();
    
    // Configure it: GET-request for the URL that retrieves leaderboard data
    xhr.open('GET', 'fetch_leaderboard.php?subject=' + encodeURIComponent(subject), true);
    
    // Define what happens on successful data retrieval
    xhr.onload = function () {
        if (xhr.status === 200) {
            // Parse JSON response
            var leaderboardData = JSON.parse(xhr.responseText);
            // Call function to display leaderboard
            displayLeaderboard(leaderboardData);
        } else {
            // Error handling
            console.log('Error occurred while fetching leaderboard data');
        }
    };
    
    // Send the request
    xhr.send();
}


// Function to display leaderboard
function displayLeaderboard(leaderboardData) {
    var leaderboardList = document.getElementById('leaderboardList');
    leaderboardList.innerHTML = '';

    leaderboardData.forEach(function(entry, index) {
        var listItem = document.createElement('li');
        listItem.innerHTML = `
            <span class="leaderboardPosition">${index + 1}</span>
            <span class="leaderboardName">${entry.user}</span>
            <span class="leaderboardScore">${entry.score}</span>
        `;
        leaderboardList.appendChild(listItem);
    });
}

// Call fetchLeaderboardData function to fetch leaderboard data from the server
fetchLeaderboardData();

    </script>
</body>
</html>
