<?php
session_start();

// Include database connection
include('connect.php');

// Check if token is provided in the URL
if (isset($_GET['token'])) {
    $token = $_GET['token'];

    // Check if token exists in the database and is not expired
    $stmt = $conn->prepare("SELECT * FROM users WHERE reset_token=? AND reset_token_expiration > ?");
    $stmt->bind_param("si", $token, time());
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Token is valid, display password reset form
        ?>
        <form method="post" action="update_password.php">
            <input type="hidden" name="token" value="<?php echo $token; ?>">
            <label>New Password:</label><br>
            <input type="password" name="password" required><br>
            <label>Confirm Password:</label><br>
            <input type="password" name="confirm_password" required><br>
            <button type="submit">Reset Password</button>
        </form>
        <?php
    } else {
        // Token is invalid or expired, display error message
        echo "Invalid or expired reset token.";
    }
} else {
    // Token is not provided in the URL, display error message
    echo "Reset token not provided.";
}
?>
