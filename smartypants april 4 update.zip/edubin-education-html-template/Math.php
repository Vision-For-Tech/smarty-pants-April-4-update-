<?php
include('navhead_math.php');
?>
    <div class="header">
        <div class="syllabus">
            <h1>Cambridge IGCSE Mathematics (0580)</h1>
            <p>Explore the fascinating world of mathematics!</p>
        </div>
        <div class="countdown">
            <span id="timer">60</span> seconds left
            <canvas id="countdownCanvas" width="200" height="200"></canvas>
        </div>
    </div>



  <!--<section style="float: left;" id="syllabus">
    <div class="syllabus_container">
      <div class="syllabus">
        <div class="dropdown">
        <a style="font-size: 2rem;" class="menu" href="#" >||| Menu</a>
        <div class="dropdown-content">
        <ul style="display: block;font-size: 1.2rem;">
          <li>1. Number</li>
          <li>2. Algebra</li>
          <li>3.Trigonometry</li>
          <li>4. Statistics</li>
          <li>5. Probability</li>
        </ul>
        </div>
        </div>
      </div>
    </div>

  </section>-->


 <section style="width: 9em; display: grid; grid-template-columns: repeat(4, 1fr); grid-gap: 5px; float: left;">
    <input type="text" id="calcdisplay" readonly style="grid-column: span 4;">
    <button class="number" onclick='appendtoDisplay("7")'>7</button>
    <button class="number" onclick='appendtoDisplay("8")'>8</button>
    <button class="number" onclick='appendtoDisplay("9")'>9</button>
    <button class="operations" onclick='appendtoDisplay("/")'>/</button>
    <button class="number" onclick='appendtoDisplay("4")'>4</button>
    <button class="number" onclick='appendtoDisplay("5")'>5</button>
    <button class="number" onclick='appendtoDisplay("6")'>6</button>
    <button class="operations" onclick='appendtoDisplay("*")'>*</button>
    <button class="number" onclick='appendtoDisplay("1")'>1</button>
    <button class="number" onclick='appendtoDisplay("2")'>2</button>
    <button class="number" onclick='appendtoDisplay("3")'>3</button>
    <button class="operations" onclick='appendtoDisplay("-")'>-</button>
    <button class="number" onclick='appendtoDisplay("0")'>0</button>
    <button class="number" onclick='appendtoDisplay(".")'>.</button>
    <button class="operations" onclick='appendtoDisplay("+")'>+</button>
    <button class="operations" onclick='calculate()' style="grid-column: span 2;">=</button>
</section>




 <section style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">
 <form style="margin-left: 200px; margin-top: 50px;" id="quizForm">
  
        <div style="background-color: aqua; border-radius: 30px;" class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">1. Solve the equation (2x<sup>2</sup> + 5x - 3 = 0).?</p>
          <label>
            <input type="radio" name="q1" value="(x = -3) or (x = 1/2) "> (x = -3) or (x = 1/2) 
          </label><br>
          <label>
            <input type="radio" name="q1" value=" (x = -1/2) or (x = 3)">  (x = -1/2) or (x = 3)
          </label><br>
          <label>
            <input type="radio" name="q1" value="(x = -3/2) or (x = 1)"> (x = -3/2) or (x = 1)
          </label><br>
          <label>
            <input type="radio" name="q1" value="(x = -1) or (x = 3/2)"> (x = -1) or (x = 3/2)
          </label><br>
        </div>
        
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <br><div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">2. What is the derivative of (f(x) = 3x<sup>4</sup> - 2x<sup>3</sup> + 5x<sup>2</sup> - 7x + 9) with respect to (x)?</p>
          <label>
            <input type="radio" name="q2" value="(12x<sup>3</sup> - 6x<sup>2</sup> + 10x - 7)"> (12x<sup>3</sup> - 6x<sup>2</sup> + 10x - 7)
          </label><br>
          <label>
            <input type="radio" name="q2" value="(12x<sup>3</sup> - 6x<sup>2</sup> + 10x - 9)"> (12x<sup>3</sup> - 6x<sup>2</sup> + 10x - 9)
          </label><br>
          <label>
            <input type="radio" name="q2" value="(12x<sup>3</sup> - 6x<sup>2</sup> + 5x - 7)"> (12x<sup>3</sup> - 6x<sup>2</sup> + 5x - 7)
          </label><br>
          <label>
            <input type="radio" name="q2" value="(12x<sup>3</sup> - 6x<sup>2</sup> + 5x - 9)">  (12x<sup>3</sup> - 6x<sup>2</sup> + 5x - 9)
          </label><br>
        </div></br>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. If (f(x) = {3x<sup>2</sup> + 5x - 2}{x + 1}), what is (f’(x)), the derivative of (f(x)) with respect to (x)?</p>
          <label>
            <input type="radio" name="q3" value="(f’(x) = {3x<sup>2</sup> + 8x + 3}{(x + 1)<sup>2</sup>})"> (f’(x) = {3x<sup>2</sup> + 8x + 3}{(x + 1)<sup>2</sup>})
          </label><br>
          <label>
            <input type="radio" name="q3" value="(f’(x) = {3x<sup>2</sup> + 8x - 3}{(x + 1)<sup>2</sup>})"> (f’(x) = {3x<sup>2</sup> + 8x - 3}{(x + 1)<sup>2</sup>})
          </label><br>
          <label>
            <input type="radio" name="q3" value="(f’(x) = {3x<sup>2</sup> + 8x - 3}{(x + 1)})"> (f’(x) = {3x<sup>2</sup> + 8x + 3}{(x + 1)})
          </label><br>
          <label>
            <input type="radio" name="q3" value="(f’(x) = {3x<sup>2</sup> + 8x - 3}{(x + 1)})"> (f’(x) = {3x<sup>2</sup> + 8x - 3}{(x + 1)})
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">4. What is the integral of (2x + 3) with respect to (x)?</p>
          <label>
            <input type="radio" name="q4" value="(x<sup>2</sup> + 3x + C)"> (x<sup>2</sup> + 3x + C)
          </label><br>
          <label>
            <input type="radio" name="q4" value="(x<sup>2</sup> + 3x<sup>2</sup> + C)"> (x<sup>2</sup> + 3x<sup>2</sup> + C)
          </label><br>
          <label>
            <input type="radio" name="q4" value="(x<sup>2</sup> + 3x<sup>3</sup> + C)"> (x<sup>2</sup> + 3x<sup>3</sup> + C)
          </label><br>
          <label>
            <input type="radio" name="q4" value="(x<sup>2</sup> + 3x<sup>4</sup> + C)"> (x<sup>2</sup> + 3x<sup>4</sup> + C)
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">5. If (f(x) = sqrt{x<sup>3</sup> -  4x + 1}), what is (f’(x)), the derivative of (f(x)) with respect to (x)?</p>
          <label>
            <input type="radio" name="q5" value=" (f’(x) = frac{3x<sup>2</sup> - 4}{2\sqrt{x<sup>3</sup> - 4x + 1}})">  (f’(x) = frac{3x<sup>2</sup> - 4}{2\sqrt{x<sup>3</sup> - 4x + 1}})
          </label><br>
          <label>
            <input type="radio" name="q5" value="(f’(x) = frac{3x<sup>2</sup> - 4}{2\sqrt{x<sup>3</sup> - 4x + 1}})"> (f’(x) = frac{3x<sup>2</sup> - 4}{2\sqrt{x<sup>3</sup> - 4x + 1}})
          </label><br>
          <label>
            <input type="radio" name="q5" value="(f’(x) = frac{3x<sup>2</sup> - 4}{2\sqrt{x<sup>3</sup> - 4x + 1}})"> (f’(x) = frac{3x<sup>2</sup> - 4}{2\sqrt{x<sup>3</sup> - 4x + 1}})
          </label><br>
          <label>
            <input type="radio" name="q5" value="(f’(x) = frac{3x<sup>2</sup> - 4}{2\sqrt{x<sup>3</sup> - 4x + 1}})"> (f’(x) = frac{3x<sup>2</sup> - 4}{2\sqrt{x<sup>3</sup> - 4x + 1}})
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">6. What is the area enclosed by the curve (y = x<sup>3</sup> - 2x<sup>2</sup> + x + 1) and the x-axis between (x = -1) and (x = 2)?</p>
          <label>
            <input type="radio" name="q6" value="(27\4)"> (27\4)
          </label><br>
          <label>
            <input type="radio" name="q6" value="(31\4)"> (31\4)
          </label><br>
          <label>
            <input type="radio" name="q6" value="(33\4)"> (33\4)
          </label><br>
          <label>
            <input type="radio" name="q6" value="(35\4)"> (35\4)
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">7.  Solve the inequality (2x<sup>2</sup> - 5x + 3 < 0).?</p>
          <label>
            <input type="radio" name="q7" value="(x < 1) or (x > 3\2)">  (x < 1) or (x > 3\2)
          </label><br>
          <label>
            <input type="radio" name="q7" value="(x < 1) or (x > 3\2)"> (x < 1) or (x > 3\2)
          </label><br>
          <label>
            <input type="radio" name="q7" value="(x < 1) or (x > 3\2)"> (x < 1) or (x > 3\2)
          </label><br>
          <label>
            <input type="radio" name="q7" value="(x < 1) or (x > 3\2)">(x < 1) or (x > 3\2)
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">8. What is the solution to the equation (log_2(x + 3) = 2)?</p>
          <label>
            <input type="radio" name="q8" value="(x = 5)"> (x = 5)
          </label><br>
          <label>
            <input type="radio" name="q8" value=" (x = 7)"> (x = 7)
          </label><br>
          <label>
            <input type="radio" name="q8" value="(x = 9)"> (x = 9)
          </label><br>
          <label>
            <input type="radio" name="q8" value="(x = 11)"> (x = 11)
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">9. If (f(x) = e<sup>x</sup>), what is (f’(x)), the derivative of (f(x)) with respect to (x)?</p>
          <label>
            <input type="radio" name="q9" value="(f’(x) = e<sup>x<sup>2</sup></sup>)"> (f’(x) = e<sup>x<sup>2</sup></sup>)
          </label><br>
          <label>
            <input type="radio" name="q9" value="(f’(x) = e<sup>x-1</sup>)"> (f’(x) = e<sup>x-1</sup>)
          </label><br>
          <label>
            <input type="radio" name="q9" value="(f’(x) = e<sup>x</sup>)"> (f’(x) = e<sup>x</sup>)
          </label><br>
          <label>
            <input type="radio" name="q9" value="(f’(x) = e<sup>x+1</sup>)"> (f’(x) = e<sup>x+1</sup>)
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">10. Evaluate the limit (lim_{x to 0} sin(x)\x).?</p>
          <label>
            <input type="radio" name="q10" value="0"> 0
          </label><br>
          <label>
            <input type="radio" name="q10" value="1"> 1
          </label><br>
          <label>
            <input type="radio" name="q10" value="pi\2"> pi\2
          </label><br>
          <label>
            <input type="radio" name="q10" value="pi"> pi
          </label><br>
        </div>

        <!--<p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>-->
        
        <button type="button" id="submitButton" onclick="submitQuiz()">Submit</button>
      </form>

    
      </div>
      
      <section style="display: flex;" id="Results">
      <div id="results"></div>
      <div id="correctAnswers"></div>
      </section>
    </section>
      





    <!--

    <section style="margin-left: 500px; font-size: 1.9rem; font-family: cursive;" id="biology">

    <div id="question_1_container">
        <div id="question1">
            <p style="font-size: 2rem;">1. What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>2. What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>What is Biology?</p>
            <ul>
                <li><input type="radio" id="answer" value="true">A</li>
                <li><input type="radio" id="answer" value="true">B</li>
                <li><input type="radio" id="answer" value="true">C</li>
                <li><input type="radio" id="answer" value="true">D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>

    -->
 </section>


    

  <footer id="footer-part">
        <div class="footer-top pt-40 pb-70">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="footer-about mt-40">
                            <div class="logo">
                                <a href="#"><img style="width: 100px; height: 100px;" src="images/smartypants.png" alt="Logo"></a>
                            </div>
                            <p>Gravida nibh vel velit auctor aliquetn quibibendum auci elit cons equat ipsutis sem nibh id elit. Duis sed odio sit amet nibh vulputate.</p>
                            <ul class="mt-20">
                                <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            </ul>
                        </div> <!-- footer about -->
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="footer-link mt-40">
                            <div class="footer-title pb-25">
                                <h6>Sitemap</h6>
                            </div>
                            <ul>
                                <li><a href="index-2.html"><i class="fa fa-angle-right"></i>Home</a></li>
                                <li><a href="about.html"><i class="fa fa-angle-right"></i>About us</a></li>
                                <li><a href="courses.html"><i class="fa fa-angle-right"></i>Courses</a></li>
                            </ul>
                            <ul>
                                <li><a href="contact.html"><i class="fa fa-angle-right"></i>Contact</a></li>
                            </ul>
                        </div> <!-- footer link -->
                    </div>
                    <div class="col-lg-2 col-md-6 col-sm-6">
                        <div class="footer-link support mt-40">
                            <div class="footer-title pb-25">
                                <h6>Support</h6>
                            </div>
                            <ul>
                                <li><a href="#"><i class="fa fa-angle-right"></i>FAQS</a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Privacy</a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Policy</a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Support</a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Documentation</a></li>
                            </ul>
                        </div> <!-- support -->
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-address mt-40">
                            <div class="footer-title pb-25">
                                <h6>Contact Us</h6>
                            </div>
                            <ul>
                                <li>
                                    <div class="icon">
                                        <i><img src="images/phone.png"></i>
                                    </div>
                                    <div class="cont">
                                        <p>+260 774029981</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-envelope-o"></i>
                                    </div>
                                    <div class="cont">
                                        <p>visionfortech@gmail.com</p>
                                    </div>
                                </li>
                            </ul>
                        </div> <!-- footer address -->
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- footer top -->
        
        <div class="footer-copyright pt-10 pb-25">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                    </div>
                    <div class="col-md-4">
                        <div class="copyright text-md-right text-center pt-15">
                           
                        </div>
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- footer copyright -->
    </footer>
    
    <!--====== FOOTER PART ENDS ======-->
   
    <!--====== BACK TO TP PART START ======-->
    
    <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>




    <script>

function drawClock(canvasId, percent, time) {
            var canvas = document.getElementById(canvasId);
            var ctx = canvas.getContext("2d");
            var radius = canvas.width / 4;
            var lineWidth = 10;

            // Clear canvas
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            // Draw outer circle
            ctx.beginPath();
            ctx.arc(radius, radius, radius - lineWidth / 2, 0, 2 * Math.PI);
            ctx.lineWidth = lineWidth;
            ctx.strokeStyle = '#ccc';
            ctx.stroke();

            // Draw progress bar
            ctx.beginPath();
            ctx.arc(radius, radius, radius - lineWidth / 2, -0.5 * Math.PI, (2 * percent - 0.5) * Math.PI);
            ctx.lineWidth = lineWidth;
            ctx.strokeStyle = '#f00'; // Change color as needed
            ctx.stroke();

            // Draw time text
            ctx.font = "20px Arial";
            ctx.fillStyle = "#000";
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";
            ctx.fillText(time, radius, radius);
        }

        function startCountdown(duration) {
            var start = Date.now();
            var interval = setInterval(function () {
                var elapsed = Date.now() - start;
                var remainingTime = duration - elapsed;
                var percent = elapsed / duration;

                // Calculate remaining minutes and seconds
                var minutes = Math.floor(remainingTime / 60000);
                var seconds = ((remainingTime % 60000) / 1000).toFixed(0);
                var time = minutes + ":" + (seconds < 10 ? '0' : '') + seconds;

                drawClock('countdownCanvas', percent, time);

                if (percent >= 1) {
                    clearInterval(interval);
                    // Countdown completed, trigger animation and sound
                }
            }, 1000);
        }

        // Start countdown for 10 seconds

      let display = document.getElementById('calcdisplay');
      function appendtoDisplay(value){
        display.innerHTML += '<p> 5678 </p>';
        console.log(value);
      }

        
            // Countdown timer
      let timeLeft = 10;
      const timerElement = document.getElementById('timer');
      const submitButton = document.getElementById('submitButton');

      window.onload = function() {
        alert("You have 10s to solve this quiz or else")
        startCountdown(10 * 1000);
      }

      function updateTimer() {
          timerElement.textContent = timeLeft;
          if (timeLeft === 0) {
              submitQuiz();
              submitButton.disabled = true;
              if (submitQuiz() === false) {
                submitButton.disabled = true;
                alert("TIME UP!!!!");

              }
          } else {
              timeLeft--;
              setTimeout(updateTimer, 1000);
          }
      }

      updateTimer();

        // Add loaded class to body after 10 seconds
      setTimeout(function() {
      document.body.classList.add('loaded');
      }, 5000,500); // 10 seconds delay

      function submitQuiz() {
  var answers = {};
  var questions = document.querySelectorAll('.question');
  
  questions.forEach(function(question, index) {
    var input = question.querySelector('input:checked');
    if (input) {
      answers[(index + 1)] = input.value;
    } else {
      answers['q' + (index + 1)] = 'No Answer';
    }
  });
  
  // Display results
  var resultsDiv = document.getElementById('results');
  resultsDiv.innerHTML = '<h2>Results:</h2>';
  Object.keys(answers).forEach(function(question, index) {
    resultsDiv.innerHTML += '<p>' + question + ': ' + answers[question] + '</p>';
  });

 var correctAnswers = ['Chlorophyll a', 'Cellular Respiration', 'Ribosome','Osmosis','Regulation of body temperature','Interphase, metaphase, prophase, anaphase, telophase','Regulation of heartbeat','Breaks down carbohydrates into simple sugars','Wind','Exchange of gases'];

 var userAnswers = answers;

 var correctDiv = document.getElementById('correctAnswers');
  correctDiv.innerHTML = '<h2>Correct Answers:</h2>';
  Object.keys(correctAnswers).forEach(function(question, index) {
    correctDiv.innerHTML += '<p style="color: green;">' + question + ': ' + correctAnswers[question - 1] + '</p>';
  });


 
var score = 0;
for (var i = 0; i < correctAnswers.length; i++) {
    if (correctAnswers[i] === userAnswers[(i + 1)]) {
        score++;
    }
 }

 // Display results
 resultsDiv.innerHTML += '<p>Total Score: ' + score + ' out of ' + correctAnswers.length + '</p>';

}

    </script> 
</body>
</html>
