<?php
include('navhead-business.php');
?>
    <div class="header">
        <div class="syllabus">
            <h1>Cambridge IGCSE Business Studies (0450)</h1>
            <p>Explore the fascinating world of business!</p>
        </div>
        <div class="countdown">
            <span id="timer">60</span> seconds left
            <canvas id="countdownCanvas" width="200" height="200"></canvas>
        </div>
    </div>



  <section style="float: left;" id="syllabus">
    <div class="syllabus_container">
      <div class="syllabus">
        <div class="dropdown">
        <a style="font-size: 2rem;" class="menu" href="#" >||| Menu</a>
        <div class="dropdown-content">
        <ul style="display: block;font-size: 1.2rem;">
          <li>1. Number</li>
          <li>2. Algebra</li>
          <li>3.Trigonometry</li>
          <li>4. Statistics</li>
          <li>5. Probability</li>
        </ul>
        </div>
        </div>
      </div>
    </div>

  </section>



 <section style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">
 <form style="margin-left: 500px; margin-top: 50px;" id="quizForm">
  
        <div style="background-color: aqua; border-radius: 30px;" class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">1. Which of the following is NOT a characteristic of a monopoly?</p>
          <label>
            <input type="radio" name="q1" value="Single seller "> Single seller
          </label><br>
          <label>
            <input type="radio" name="q1" value=" Price taker">  Price taker
          </label><br>
          <label>
            <input type="radio" name="q1" value="Barriers to entry"> Barriers to entry
          </label><br>
          <label>
            <input type="radio" name="q1" value="Unique product"> Unique product
          </label><br>
        </div>
        
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <br><div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">2. What type of market structure is characterized by a large number of small firms selling similar but not identical products?</p>
          <label>
            <input type="radio" name="q2" value="Monopoly"> Monopoly
          </label><br>
          <label>
            <input type="radio" name="q2" value="Oligopoly"> Oligopoly
          </label><br>
          <label>
            <input type="radio" name="q2" value="Perfect competition"> Perfect competition
          </label><br>
          <label>
            <input type="radio" name="q2" value="Monopolistic competition">  Monopolistic competition
          </label><br>
        </div></br>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which of the following is NOT a factor affecting the choice of channel of distribution?</p>
          <label>
            <input type="radio" name="q3" value="Nature of the product"> Nature of the product
          </label><br>
          <label>
            <input type="radio" name="q3" value="Government regulations">Government regulations
          </label><br>
          <label>
            <input type="radio" name="q3" value="Availability of resources"> Availability of resources
          </label><br>
          <label>
            <input type="radio" name="q3" value="Production costs"> Production costs
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">4. What is the main disadvantage of using a democratic leadership style?</p>
          <label>
            <input type="radio" name="q4" value="Slow decision-making process"> Slow decision-making process
          </label><br>
          <label>
            <input type="radio" name="q4" value="Lack of employee motivation"> Lack of employee motivation
          </label><br>
          <label>
            <input type="radio" name="q4" value="Authoritarian control"> Authoritarian control
          </label><br>
          <label>
            <input type="radio" name="q4" value="Inflexible management structure"> Inflexible management structure
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">5. Which of the following is NOT a method of market research?</p>
          <label>
            <input type="radio" name="q5" value=" Surveys">  Surveys
          </label><br>
          <label>
            <input type="radio" name="q5" value="Observations"> Observations
          </label><br>
          <label>
            <input type="radio" name="q5" value="Product sampling"> Product sampling
          </label><br>
          <label>
            <input type="radio" name="q5" value="Product promotion"> Product promotion
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">6. What is the purpose of a SWOT analysis?</p>
          <label>
            <input type="radio" name="q6" value="To identify strengths, weaknesses, opportunities, and threats"> To identify strengths, weaknesses, opportunities, and threats
          </label><br>
          <label>
            <input type="radio" name="q6" value="To determine market demand"> To determine market demand
          </label><br>
          <label>
            <input type="radio" name="q6" value="To calculate break-even points"> To calculate break-even points
          </label><br>
          <label>
            <input type="radio" name="q6" value="To forecast sales figures"> To forecast sales figures
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">7.  Which of the following is NOT a factor affecting the choice of pricing strategy?</p>
          <label>
            <input type="radio" name="q7" value="Cost of production">  Cost of production
          </label><br>
          <label>
            <input type="radio" name="q7" value="Market competition"> Market competition
          </label><br>
          <label>
            <input type="radio" name="q7" value="Government regulations"> Government regulations
          </label><br>
          <label>
            <input type="radio" name="q7" value="Employee salaries">Employee salaries
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">8. What is the term for the process of transferring ownership of goods or services to a customer in exchange for money?</p>
          <label>
            <input type="radio" name="q8" value="Marketing"> Marketing
          </label><br>
          <label>
            <input type="radio" name="q8" value=" Promotion"> Promotion
          </label><br>
          <label>
            <input type="radio" name="q8" value="Distribution"> Distribution
          </label><br>
          <label>
            <input type="radio" name="q8" value="Selling"> Selling
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">9. Which of the following is NOT a function of human resource management?</p>
          <label>
            <input type="radio" name="q9" value="Recruitment and selection"> Recruitment and selection
          </label><br>
          <label>
            <input type="radio" name="q9" value="Production planning"> Production planning
          </label><br>
          <label>
            <input type="radio" name="q9" value="Training and development"> Training and development
          </label><br>
          <label>
            <input type="radio" name="q9" value="Performance appraisal"> Performance appraisal
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">10. What is the term for the process of converting inputs into outputs by adding value to raw materials or components?</p>
          <label>
            <input type="radio" name="q10" value="Production"> Production
          </label><br>
          <label>
            <input type="radio" name="q10" value="Marketing"> Marketing
          </label><br>
          <label>
            <input type="radio" name="q10" value="Finance"> Finance
          </label><br>
          <label>
            <input type="radio" name="q10" value="Distribution"> Distribution
          </label><br>
        </div>

        <!--<p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>-->
        
        <button type="button" id="submitButton" onclick="submitQuiz()">Submit</button>
      </form>

    
      </div>
      
      <section style="display: flex;" id="Results">
      <div id="results"></div>
      <div id="correctAnswers"></div>
      </section>
    </section>
      





    <!--

    <section style="margin-left: 500px; font-size: 1.9rem; font-family: cursive;" id="biology">

    <div id="question_1_container">
        <div id="question1">
            <p style="font-size: 2rem;">1. What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>2. What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>What is Biology?</p>
            <ul>
                <li><input type="radio" id="answer" value="true">A</li>
                <li><input type="radio" id="answer" value="true">B</li>
                <li><input type="radio" id="answer" value="true">C</li>
                <li><input type="radio" id="answer" value="true">D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>

    -->
 </section>


    

  <footer id="footer-part">
        <div class="footer-top pt-40 pb-70">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="footer-about mt-40">
                            <div class="logo">
                                <a href="#"><img style="width: 100px; height: 100px;" src="images/smartypants.png" alt="Logo"></a>
                            </div>
                            <p>Gravida nibh vel velit auctor aliquetn quibibendum auci elit cons equat ipsutis sem nibh id elit. Duis sed odio sit amet nibh vulputate.</p>
                            <ul class="mt-20">
                                <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            </ul>
                        </div> <!-- footer about -->
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="footer-link mt-40">
                            <div class="footer-title pb-25">
                                <h6>Sitemap</h6>
                            </div>
                            <ul>
                                <li><a href="index-2.html"><i class="fa fa-angle-right"></i>Home</a></li>
                                <li><a href="about.html"><i class="fa fa-angle-right"></i>About us</a></li>
                                <li><a href="courses.html"><i class="fa fa-angle-right"></i>Courses</a></li>
                            </ul>
                            <ul>
                                <li><a href="contact.html"><i class="fa fa-angle-right"></i>Contact</a></li>
                            </ul>
                        </div> <!-- footer link -->
                    </div>
                    <div class="col-lg-2 col-md-6 col-sm-6">
                        <div class="footer-link support mt-40">
                            <div class="footer-title pb-25">
                                <h6>Support</h6>
                            </div>
                            <ul>
                                <li><a href="#"><i class="fa fa-angle-right"></i>FAQS</a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Privacy</a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Policy</a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Support</a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Documentation</a></li>
                            </ul>
                        </div> <!-- support -->
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-address mt-40">
                            <div class="footer-title pb-25">
                                <h6>Contact Us</h6>
                            </div>
                            <ul>
                                <li>
                                    <div class="icon">
                                        <i><img src="images/phone.png"></i>
                                    </div>
                                    <div class="cont">
                                        <p>+260 774029981</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-envelope-o"></i>
                                    </div>
                                    <div class="cont">
                                        <p>visionfortech@gmail.com</p>
                                    </div>
                                </li>
                            </ul>
                        </div> <!-- footer address -->
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- footer top -->
        
        <div class="footer-copyright pt-10 pb-25">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                    </div>
                    <div class="col-md-4">
                        <div class="copyright text-md-right text-center pt-15">
                           
                        </div>
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- footer copyright -->
    </footer>
    
    <!--====== FOOTER PART ENDS ======-->
   
    <!--====== BACK TO TP PART START ======-->
    
    <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>




    <script>

            // Countdown timer
            let timeLeft = 100;
      const timerElement = document.getElementById('timer');
      const submitButton = document.getElementById('submitButton');

      window.onload = function() {
        alert("You have 100s to solve this quiz or else")
      }


      function updateTimer() {
          timerElement.textContent = timeLeft;
          if (timeLeft === 0) {
              submitQuiz();
                submitButton.disabled = true;
                alert("TIME UP!!!!");
          } else {
              timeLeft--;
              setTimeout(updateTimer, 1000);
          }
      }

      updateTimer();

        // Add loaded class to body after 10 seconds
      setTimeout(function() {
      document.body.classList.add('loaded');
      }, 5000,500); // 10 seconds delay

      function submitQuiz() {
  var subject = 'Biology';
  var answers = {};
  var questions = document.querySelectorAll('.question');
  
  questions.forEach(function(question, index) {
    var input = question.querySelector('input:checked');
    if (input) {
      answers[(index + 1)] = input.value;
    } else {
      answers['q' + (index + 1)] = 'No Answer';
    }
    sendScoreToPHP(score,subject);
  });
  
  // Display results
  var resultsDiv = document.getElementById('results');
  //resultsDiv.innerHTML = '<h2>Results:</h2>';
  //Object.keys(answers).forEach(function(question, index) {
  //  resultsDiv.innerHTML += '<p>' + question + ': ' + answers[question] + '</p>';
  //});

 var correctAnswers = ['Chlorophyll a', 'Cellular Respiration', 'Ribosome','Osmosis','Regulation of body temperature','Interphase, metaphase, prophase, anaphase, telophase','Regulation of heartbeat','Breaks down carbohydrates into simple sugars','Wind','Exchange of gases'];

 var userAnswers = answers;



 //var correctDiv = document.getElementById('correctAnswers');
  //correctDiv.innerHTML = '<h2>Correct Answers:</h2>';
  //Object.keys(correctAnswers).forEach(function(question, index) {
    //correctDiv.innerHTML += '<p style="color: green;">' + question + ': ' + correctAnswers[question - 1] + '</p>';
  //});


 
var score = 0;
for (var i = 0; i < correctAnswers.length; i++) {
    if (correctAnswers[i] === userAnswers[(i + 1)]) {
        score++;
    }
 }

 // Display results
 resultsDiv.innerHTML += '<h2>Biology</h2><br></br><p>Total Score: ' + score + ' out of ' + correctAnswers.length + '</p>';
 
 var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("submitButton");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal
btn.onclick = function() {
modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
modal.style.display = "none";
}


}

function sendScoreToPHP(score,subject) {
    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();
    
    // Configure it: POST request for the URL store_score.php
    xhr.open('POST', 'store_score.php', true);
    
    // Set up the request header
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    
    // Define what happens on successful data submission
    xhr.onload = function () {
        if (xhr.status === 200) {
            // Request was successful, do something if needed
            console.log('Form sent successfully');
        } else {
            // Error handling
            console.log('Error occurred while sending score');
        }
    };
    
    // Send the request with score, username, and subject
    xhr.send('score=' + encodeURIComponent(score) +  '&subject=' + encodeURIComponent(subject));
}




    </script> 
</body>
</html>
