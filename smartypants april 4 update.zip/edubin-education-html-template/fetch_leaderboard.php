<?php
include('connect.php');
// Fetch the subject from the GET parameters
$subject = isset($_GET['subject']) ? $_GET['subject'] : '';


// Fetch leaderboard data from the database for the selected subject
$sql = "SELECT user, score, subject FROM scores WHERE subject = ? ORDER BY score DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $subject);
$stmt->execute();
$result = $stmt->get_result();

// Prepare array to hold leaderboard data
$leaderboardData = array();

if ($result->num_rows > 0) {
    // Fetch data and push to the array
    while($row = $result->fetch_assoc()) {
        $leaderboardData[] = $row;
    }
}

// Close connection
$stmt->close();
$conn->close();

// Return leaderboard data as JSON
header('Content-Type: application/json');
echo json_encode($leaderboardData);
?>
