<?php
include('navhead-geo.php');
?>
    <div class="header">
        <div class="syllabus">
            <h1>Cambridge IGCSE Geography (0450)</h1>
            <p>Explore the fascinating world of geography!</p>
        </div>
        <div class="countdown">
            <span id="timer">60</span> seconds left
            <canvas id="countdownCanvas" width="200" height="200"></canvas>
        </div>
    </div>



  <section style="float: left;" id="syllabus">
    <div class="syllabus_container">
      <div class="syllabus">
        <div class="dropdown">
        <a style="font-size: 2rem;" class="menu" href="#" >||| Menu</a>
        <div class="dropdown-content">
        <ul style="display: block;font-size: 1.2rem;">
          <li>1. Number</li>
          <li>2. Algebra</li>
          <li>3.Trigonometry</li>
          <li>4. Statistics</li>
          <li>5. Probability</li>
        </ul>
        </div>
        </div>
      </div>
    </div>

  </section>



 <section style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">
 <form style="margin-left: 200px; margin-top: 50px;" id="quizForm">
  
        <div style="background-color: aqua; border-radius: 30px;" class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">1. What is the term for the process by which a glacier erodes the landscape through the abrasion of rock fragments carried by the ice?</p>
          <label>
            <input type="radio" name="q1" value="Corrasion">Corrasion
          </label><br>
          <label>
            <input type="radio" name="q1" value=" Attrition"> Attrition
          </label><br>
          <label>
            <input type="radio" name="q1" value=" Plucking"> Plucking
          </label><br>
          <label>
            <input type="radio" name="q1" value="Hydraulic action">Hydraulic action
          </label><br>
        </div>
        
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <br><div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">2. Which of the following is NOT a primary factor affecting climate?</p>
          <label>
            <input type="radio" name="q2" value="Latitude">Latitude
          </label><br>
          <label>
            <input type="radio" name="q2" value="Altitude">Altitude
          </label><br>
          <label>
            <input type="radio" name="q2" value="Ocean currents">Ocean currents

          </label><br>
          <label>
            <input type="radio" name="q2" value="Soil composition">Soil composition
          </label><br>
        </div></br>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. What is the name of the line that divides Earth into two equal halves, representing the point of zero degrees latitude?</p>
          <label>
            <input type="radio" name="q3" value="Nitrogen">Equator
          </label><br>
          <label>
            <input type="radio" name="q3" value="Phosphorus">Tropic of Cancer
          </label><br>
          <label>
            <input type="radio" name="q3" value="Calcium">Prime Meridian
          </label><br>
          <label>
            <input type="radio" name="q3" value="Potassium">International Date Line
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">4. Which of the following types of precipitation occurs when air cools below its dew point and water vapor condenses directly into ice crystals?</p>
          <label>
            <input type="radio" name="q4" value="Rain"> Rain
          </label><br>
          <label>
            <input type="radio" name="q4" value="Snow">Snow
          </label><br>
          <label>
            <input type="radio" name="q4" value="Sleet">Sleet
          </label><br>
          <label>
            <input type="radio" name="q4" value="Hail">Hail
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">5. What is the term for the process by which rocks are broken down into smaller fragments through physical disintegration or chemical decomposition?</p>
          <label>
            <input type="radio" name="q5" value="Weathering">Weathering
          </label><br>
          <label>
            <input type="radio" name="q5" value="Erosion">Erosion
          </label><br>
          <label>
            <input type="radio" name="q5" value="Deposition">Deposition
          </label><br>
          <label>
            <input type="radio" name="q5" value="Compaction">Compaction
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">6. What is the main cause of soil erosion?</p>
          <label>
            <input type="radio" name="q6" value=" Deforestation"> Deforestation
          </label><br>
          <label>
            <input type="radio" name="q6" value="Urbanization">Urbanization
          </label><br>
          <label>
            <input type="radio" name="q6" value="Volcanic activity">Volcanic activity
          </label><br>
          <label>
            <input type="radio" name="q6" value="Glacier movement">Glacier movement
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">7. Which of the following is NOT a primary greenhouse gas?</p>
          <label>
            <input type="radio" name="q7" value="Carbon dioxide">Carbon dioxide
          </label><br>
          <label>
            <input type="radio" name="q7" value="Methane">Methane
          </label><br>
          <label>
            <input type="radio" name="q7" value="Nitrous oxide">Nitrous oxide
          </label><br>
          <label>
            <input type="radio" name="q7" value="Oxygen">Oxygen
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">8. What is the term for the process by which water vapor is released from plants into the atmosphere?</p>
          <label>
            <input type="radio" name="q8" value="Condensation">Condensation
          </label><br>
          <label>
            <input type="radio" name="q8" value="Transpiration">Transpiration
          </label><br>
          <label>
            <input type="radio" name="q8" value=" Evaporation"> Evaporation
          </label><br>
          <label>
            <input type="radio" name="q8" value="Precipitation">Precipitation
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">9.Which of the following is an example of a landform created by deposition?</p>
          <label>
            <input type="radio" name="q9" value="Delta">Delta
          </label><br>
          <label>
            <input type="radio" name="q9" value="Canyon">Canyon
          </label><br>
          <label>
            <input type="radio" name="q9" value="Volcano">Volcano
          </label><br>
          <label>
            <input type="radio" name="q9" value="Escarpment">Escarpment
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">10. What is the term for the process by which rocks and sediments are transported from one place to another by wind, water, or ice?</p>
          <label>
            <input type="radio" name="q10" value="Weathering">Weathering
          </label><br>
          <label>
            <input type="radio" name="q10" value="Erosion">Erosion
          </label><br>
          <label>
            <input type="radio" name="q10" value="Deposition">Deposition
          </label><br>
          <label>
            <input type="radio" name="q10" value="Transportation
">Transportation

          </label><br>
        </div>

        <!--<p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>

        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        <div class="question">
          <p style="font-size: 2rem; font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;">3. Which organelle is responsible for protein synthesis in a cell?</p>
          <label>
            <input type="radio" name="q3" value="Ribosome"> Ribosome
          </label><br>
          <label>
            <input type="radio" name="q3" value="Nucleus"> Nucleus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Golgi apparatus"> Golgi apparatus
          </label><br>
          <label>
            <input type="radio" name="q3" value="Endoplasmic reticulum"> Endoplasmic reticulum
          </label><br>
        </div>-->
        
        <button type="button" id="submitButton" onclick="submitQuiz()">Submit</button>
      </form>

    
      </div>
      
      <section style="display: flex;" id="Results">
      <div id="results"></div>
      <div id="correctAnswers"></div>
      </section>
    </section>
      





    <!--

    <section style="margin-left: 500px; font-size: 1.9rem; font-family: cursive;" id="biology">

    <div id="question_1_container">
        <div id="question1">
            <p style="font-size: 2rem;">1. What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>2. What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>What is Biology?</p>
            <ul>
                <li><input type="radio" id="answer" value="true">A</li>
                <li><input type="radio" id="answer" value="true">B</li>
                <li><input type="radio" id="answer" value="true">C</li>
                <li><input type="radio" id="answer" value="true">D</li>
            </ul>
        </div>
    </div>
    <div id="question_1_container">
        <div id="question1">
            <p>What is Biology?</p>
            <ul>
                <li>A</li>
                <li>B</li>
                <li>C</li>
                <li>D</li>
            </ul>
        </div>
    </div>

    -->
 </section>


    

  <footer id="footer-part">
        <div class="footer-top pt-40 pb-70">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="footer-about mt-40">
                            <div class="logo">
                                <a href="#"><img style="width: 100px; height: 100px;" src="images/smartypants.png" alt="Logo"></a>
                            </div>
                            <p>Gravida nibh vel velit auctor aliquetn quibibendum auci elit cons equat ipsutis sem nibh id elit. Duis sed odio sit amet nibh vulputate.</p>
                            <ul class="mt-20">
                                <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            </ul>
                        </div> <!-- footer about -->
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="footer-link mt-40">
                            <div class="footer-title pb-25">
                                <h6>Sitemap</h6>
                            </div>
                            <ul>
                                <li><a href="index-2.html"><i class="fa fa-angle-right"></i>Home</a></li>
                                <li><a href="about.html"><i class="fa fa-angle-right"></i>About us</a></li>
                                <li><a href="courses.html"><i class="fa fa-angle-right"></i>Courses</a></li>
                            </ul>
                            <ul>
                                <li><a href="contact.html"><i class="fa fa-angle-right"></i>Contact</a></li>
                            </ul>
                        </div> <!-- footer link -->
                    </div>
                    <div class="col-lg-2 col-md-6 col-sm-6">
                        <div class="footer-link support mt-40">
                            <div class="footer-title pb-25">
                                <h6>Support</h6>
                            </div>
                            <ul>
                                <li><a href="#"><i class="fa fa-angle-right"></i>FAQS</a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Privacy</a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Policy</a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Support</a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Documentation</a></li>
                            </ul>
                        </div> <!-- support -->
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-address mt-40">
                            <div class="footer-title pb-25">
                                <h6>Contact Us</h6>
                            </div>
                            <ul>
                                <li>
                                    <div class="icon">
                                        <i><img src="images/phone.png"></i>
                                    </div>
                                    <div class="cont">
                                        <p>+260 774029981</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-envelope-o"></i>
                                    </div>
                                    <div class="cont">
                                        <p>visionfortech@gmail.com</p>
                                    </div>
                                </li>
                            </ul>
                        </div> <!-- footer address -->
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- footer top -->
        
        <div class="footer-copyright pt-10 pb-25">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                    </div>
                    <div class="col-md-4">
                        <div class="copyright text-md-right text-center pt-15">
                           
                        </div>
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- footer copyright -->
    </footer>
    
    <!--====== FOOTER PART ENDS ======-->
   
    <!--====== BACK TO TP PART START ======-->
    
    <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>




    <script>

            // Countdown timer
            let timeLeft = 100;
      const timerElement = document.getElementById('timer');
      const submitButton = document.getElementById('submitButton');

      window.onload = function() {
        alert("You have 100s to solve this quiz or else")
      }


      function updateTimer() {
          timerElement.textContent = timeLeft;
          if (timeLeft === 0) {
              submitQuiz();
                submitButton.disabled = true;
                alert("TIME UP!!!!");
          } else {
              timeLeft--;
              setTimeout(updateTimer, 1000);
          }
      }

      updateTimer();

        // Add loaded class to body after 10 seconds
      setTimeout(function() {
      document.body.classList.add('loaded');
      }, 5000,500); // 10 seconds delay

      function submitQuiz() {
  var subject = 'Biology';
  var answers = {};
  var questions = document.querySelectorAll('.question');
  
  questions.forEach(function(question, index) {
    var input = question.querySelector('input:checked');
    if (input) {
      answers[(index + 1)] = input.value;
    } else {
      answers['q' + (index + 1)] = 'No Answer';
    }
    sendScoreToPHP(score,subject);
  });
  
  // Display results
  var resultsDiv = document.getElementById('results');
  //resultsDiv.innerHTML = '<h2>Results:</h2>';
  //Object.keys(answers).forEach(function(question, index) {
  //  resultsDiv.innerHTML += '<p>' + question + ': ' + answers[question] + '</p>';
  //});

 var correctAnswers = ['Chlorophyll a', 'Cellular Respiration', 'Ribosome','Osmosis','Regulation of body temperature','Interphase, metaphase, prophase, anaphase, telophase','Regulation of heartbeat','Breaks down carbohydrates into simple sugars','Wind','Exchange of gases'];

 var userAnswers = answers;



 //var correctDiv = document.getElementById('correctAnswers');
  //correctDiv.innerHTML = '<h2>Correct Answers:</h2>';
  //Object.keys(correctAnswers).forEach(function(question, index) {
    //correctDiv.innerHTML += '<p style="color: green;">' + question + ': ' + correctAnswers[question - 1] + '</p>';
  //});


 
var score = 0;
for (var i = 0; i < correctAnswers.length; i++) {
    if (correctAnswers[i] === userAnswers[(i + 1)]) {
        score++;
    }
 }

 // Display results
 resultsDiv.innerHTML += '<h2>Biology</h2><br></br><p>Total Score: ' + score + ' out of ' + correctAnswers.length + '</p>';
 
 var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("submitButton");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal
btn.onclick = function() {
modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
modal.style.display = "none";
}


}

function sendScoreToPHP(score,subject) {
    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();
    
    // Configure it: POST request for the URL store_score.php
    xhr.open('POST', 'store_score.php', true);
    
    // Set up the request header
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    
    // Define what happens on successful data submission
    xhr.onload = function () {
        if (xhr.status === 200) {
            // Request was successful, do something if needed
            console.log('Form sent successfully');
        } else {
            // Error handling
            console.log('Error occurred while sending score');
        }
    };
    
    // Send the request with score, username, and subject
    xhr.send('score=' + encodeURIComponent(score) +  '&subject=' + encodeURIComponent(subject));
}




    </script> 
</body>
</html>
