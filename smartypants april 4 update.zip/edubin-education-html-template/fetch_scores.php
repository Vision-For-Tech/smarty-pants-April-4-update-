<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smartypants";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch scores for the selected subject
$subject = isset($_GET['subject']) ? $_GET['subject'] : '';

$sql = "SELECT (user, score, subject) FROM scores WHERE subject = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sis", $subject);
$stmt->execute();
$result = $stmt->get_result();

// Prepare array to hold scores data
$scoresData = array();

if ($result->num_rows > 0) {
    // Fetch data and push to the array
    while($row = $result->fetch_assoc()) {
        $scoresData[] = $row;
    }
}

// Close connection
$stmt->close();
$conn->close();

// Return scores data as JSON
header('Content-Type: application/json');
echo json_encode($scoresData);
?>
