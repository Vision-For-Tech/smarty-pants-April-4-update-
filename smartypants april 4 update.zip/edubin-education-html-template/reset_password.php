<?php
session_start();

// Include database connection
include('connect.php');

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect email from the form
    $email = $_POST['email'];

    // Generate a unique token
    $token = bin2hex(random_bytes(32));

    // Set expiration time for token (e.g., 1 hour)
    $expiration = time() + 3600; // 1 hour from now

    // Store token and expiration time in the database for the user with the provided email
    $stmt = $conn->prepare("UPDATE users SET reset_token=?, reset_token_expiration=? WHERE email=?");
    $stmt->bind_param("sis", $token, $expiration, $email);
    $stmt->execute();
    $stmt->close();

    // Send email with password reset link containing the token
    $reset_link = "https://yourwebsite.com/reset_password.php?token=" . $token;
    $to = $email;
    $subject = "Password Reset Request";
    $message = "To reset your password, click the following link: $reset_link";
    $headers = "From: your_email@example.com\r\n";
    $headers .= "Reply-To: your_email@example.com\r\n";
    $headers .= "Content-Type: text/html\r\n";

    if (mail($to, $subject, $message, $headers)) {
        echo "An email with instructions to reset your password has been sent to your email address.";
    } else {
        echo "Failed to send reset email. Please try again later.";
    }
}
?>

<!-- HTML form for password reset request -->
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <label>Email:</label><br>
    <input type="email" name="email" required><br>
    <button type="submit">Reset Password</button>
</form>
