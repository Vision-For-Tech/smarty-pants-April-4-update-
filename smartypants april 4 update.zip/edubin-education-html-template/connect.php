<?php
$conn = mysqli_connect('localhost','root','','smartypants')or die(mysqli_error());
?>
